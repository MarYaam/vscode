TypeScript is authored by:
* Abubaker Bashir
* Adam Freidin
* Adi Dahiya
* Ahmad Farid
* Alex Eagle
* Alexander Kuvaev
* Anders Hejlsberg
* Andrew Z Allen
* Andy Hanson
* Anil Anar
* Anton Tolmachev
* Arnav Singh
* Arthur Ozga
* Asad Saeeduddin
* Avery Morin
* Basarat Ali Syed
* Ben Duffield
* Bill Ticehurst
* Blake Embrey
* Bowden Kelly
* Brett Mayen
* Bryan Forbes
* Caitlin Potter
* Chris Bubernak
* Chuck Jazdzewski
* Colby Russell
* Colin Snover
* Cyrus Najmabadi
* Dan Corder
* Dan Quirk
* Daniel Rosenwasser
* David Li
* David Souther
* Denis Nedelyaev
* Dick van den Brink
* Dirk Bäumer
* Dirk Holtwick
* Doug Ilijev
* Erik Edrosa
* Ethan Rubio
* Evan Martin
* Evan Sebastian
* Eyas Sharaiha
* @falsandtru
* Frank Wallis
* František Žiačik
* Gabriel Isenberg
* Gilad Peleg
* Graeme Wicksted
* Guillaume Salles
* Guy Bedford
* Harald Niesche
* Herrington Darkholme
* Iain Monro
* Ingvar Stepanyan
* Isiah Meadows
* Ivo Gabe de Wolff
* James Whitney
* Jason Freeman
* Jason Killian
* Jason Ramsay
* JBerger
* Jed Mao
* Jeffrey Morlan
* Jesse Schalken
* Jiri Tobisek
* Johannes Rieken
* John Vilk
* Jonathan Bond-Caron
* Jonathan Park
* Jonathan Toland
* Jonathan Turner
* Josh Kalderimis
* Josh Soref
* Juan Luis Boya García
* Julian Williams
* Kagami Sascha Rosylight
* Kanchalai Tanglertsampan
* Keith Mashinter
* Ken Howard
* Kenji Imamula
* Kyle Kelley
* Lorant Pinter
* Lucien Greathouse
* Martin Vseticka
* Masahiro Wakame
* Matt McCutchen
* Max Deepfield
* Micah Zoltu
* Mohamed Hegazy
* Nathan Shively-Sanders
* Nathan Yee
* Nima Zahedi
* Noj Vek
* Oleg Mihailik
* Oleksandr Chekhovskyi
* Oskar Segersva¨rd
* Patrick Zhong
* Paul van Brenk
* @pcbro
* Pedro Maltez
* Philip Bulley
* Piero Cangianiello
* @piloopin
* Prayag Verma
* @progre
* Punya Biswal
* Rado Kirov
* Richard Knoll
* Ron Buckton
* Rowan Wyborn
* Ryan Cavanaugh
* Ryohei Ikegami
* Sarangan Rajamanickam
* Sheetal Nandi
* Shengping Zhong
* Shyyko Serhiy
* Simon Hürlimann
* Solal Pirelli
* Stan Thomas
* Stanislav Sysoev
* Steve Lucco
* Sébastien Arod
* @T18970237136
* Tarik Ozket
* Tien Hoanhtien
* Tim Perry
* Tim Viiding-Spader
* Tingan Ho
* Todd Thomson
* togru
* Tomas Grubliauskas
* TruongSinh Tran-Nguyen
* Vilic Vane
* Vladimir Matveev
* Wesley Wigham
* York Yao
* Yuichi Nukiyama
* Zev Spitz
* Zhengbo Li